package kitty.lib;

public interface IEvent {
	public int getEventID();
	public boolean run();
}
